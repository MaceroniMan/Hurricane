VERSION = "v0.1.1"
KEY = "hurricane-0.1.1"
WIDTH = 70