def craft(player, items, cr, world):
  pass