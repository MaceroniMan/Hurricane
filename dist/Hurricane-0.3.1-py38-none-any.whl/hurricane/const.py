VERSION = "v0.3.1"
KEY = "hurricane-0.3.1"
WIDTH = 70