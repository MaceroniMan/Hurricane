# TF2 coconut situation

print("Loading Game...")