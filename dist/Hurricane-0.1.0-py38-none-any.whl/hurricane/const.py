VERSION = "v0.1.0"
KEY = "hurricane-0.1.0"