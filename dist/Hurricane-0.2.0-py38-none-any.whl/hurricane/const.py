VERSION = "v0.2.0"
KEY = "hurricane-0.2.0"
WIDTH = 70